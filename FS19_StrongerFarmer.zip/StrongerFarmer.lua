-- Author:JustDen
-- Name: StrongerFarmer.lua

StrongerFarmer = {}
addModEventListener(StrongerFarmer)

_MAX_PICKABLE_OBJECT_MASS = 100 -- 100 tons
_MAX_PICKABLE_OBJECT_DISTANCE = 15 -- 15 meters?

frameticks = 100
active = false
messsage = ""
defaultMass = 0
defaultDistance = 0

function StrongerFarmer:loadMap(name)
   defaultMass = Player.MAX_PICKABLE_OBJECT_MASS
   defaultDistance = Player.MAX_PICKABLE_OBJECT_DISTANCE
end

function StrongerFarmer:deleteMap()
end

function StrongerFarmer:mouseEvent(posX, posY, isDown, isUp, button)
end

function StrongerFarmer:keyEvent(unicode, sym, modifier, isDown)
end

function StrongerFarmer:update(dt)
end

function StrongerFarmer:draw(StrongerFarmer)
   if message ~= nil and frameticks > 0 then
      renderText(0.33,0.33,0.02,message)
      frameticks = frameticks - 1
   end   
end

function StrongerFarmer:keyEvent(nicode, sym, modifier, isDown)
--    if sym == Input.KEY_i and isDown == true and modifier == 4160 then
    if sym == Input.KEY_q and isDown == true and modifier == 4160 then
		if active == false then
			message = "Stronger Farmer Activating..."
			print(message)
			Player.MAX_PICKABLE_OBJECT_MASS = _MAX_PICKABLE_OBJECT_MASS
			Player.MAX_PICKABLE_OBJECT_DISTANCE = _MAX_PICKABLE_OBJECT_DISTANCE
			active = true
			frameticks = 100
		elseif active == true then
			-- message = "Stronger Farmer Deactivating. Strength = "..defaultMass.." Distance = "..defaultDistance
			message = "Stronger Farmer Deactivating..."
			print(message)
			Player.MAX_PICKABLE_OBJECT_MASS = defaultMass
			Player.MAX_PICKABLE_OBJECT_DISTANCE = defaultDistance
			active = false
			frameticks = 100
		end
	end	
end
